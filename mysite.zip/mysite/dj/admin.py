from django.contrib import admin
from dj.models import contact,Team

# Register your models here.
admin.site.register(contact)
admin.site.register(Team)