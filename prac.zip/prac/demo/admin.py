from django.contrib import admin
from demo.models import Question,Choice,department,employees,student
admin.site.register(Question)
admin.site.register(Choice)
admin.site.register(department)
admin.site.register(employees)
admin.site.register(student)
# Register your models here.
