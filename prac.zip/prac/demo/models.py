from django.db import models


class Question(models.Model):
    question_text = models.CharField(max_length=200)
    noOfQuestion = models.IntegerField()
    pub_date = models.DateTimeField("date published")


class Choice(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)

class department(models.Model):
    depName=models.CharField(max_length=100)
    employees=models.IntegerField()
    HOD=models.CharField(max_length=100)
    depPhone= models.IntegerField()
    depImail=models.EmailField()
class employees(models.Model):
    empName=models.CharField(max_length=100)
    salary=models.IntegerField()
    designation=models.CharField(max_length=100)
class student(models.Model):
    studentName=models.CharField(max_length=200)
    studentRollNo=models.IntegerField()
    collegeId=models.IntegerField()
    collegeName=models.CharField(max_length=300)
    subject1Marks=models.IntegerField()
    subject2Marks=models.IntegerField()
    subject3Marks=models.IntegerField()
    subject4Marks=models.IntegerField()
    subject5Marks=models.IntegerField()
    totalMarks=models.IntegerField()
    persentage=models.IntegerField()
    grade=models.CharField(max_length=1)







