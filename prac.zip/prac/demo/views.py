from django.shortcuts import render
from demo.models import employees,student

# Create your views here.
def index(request):
    return render(request,'index.html')

def about(request):
    contex={
        'name':'jayesh',
        'b_name':'IT',
        'c_name':'SVKM',
        'roll_no':0o6,
        'sap_id':14004210005
    }
    return render(request,'aboutus.html',contex)

def contact(request):
    return render(request,'contact.html')

def service(request):
    return render(request,'service.html')

def Sum(request):
    am= int(request.POST['am'])
    ir=int(request.POST['ir'])
    ye=int(request.POST['ye'])
    sum=(am*ir*ye)/100
    return render(request,'sum.html',{'result':sum})
def sud(request):
    return render(request,'student.html')
def msheet(request):
    s_name=request.POST['name']
    roll=request.POST['roll']
    clg_name=request.POST['clg_name']
    clg_id=request.POST['clg_id']
    phy=int(request.POST['phy'])
    chem=int(request.POST['chem'])
    math=int(request.POST['math'])
    eng=int(request.POST['eng'])
    mrt=int(request.POST['mrt'])
    total=phy+chem+math+eng+mrt
    per=(total/500)*100
    if phy>=40 and chem>=40 and math>=40 and eng>=40 and mrt>=40:
        res="pass"
    else:
        res="fail"

    if per <=100 and per>90 and res=="pass":
        grade='A+'
    elif per <=90 and per>80 and res=="pass":
        grade='A'
    elif per <=80 and per>60 and res=="pass":
        grade='B'
    elif per <=60 and per>=40 and res=="pass":
        grade='C'
    else:
        grade='D'

    sheet={
        "s_name":s_name,
        "roll":roll,
        "clg_name": clg_name,
        "clg_id":clg_id,
        "phy":phy,
        "chem":chem,
        "math": math,
        "eng":eng,
        "mrt":mrt,
        "total":total,
        "per":per,
        "res":res,
        "grade":grade

    }
    obj=student(studentName=s_name,studentRollNo=roll,collegeId=clg_id,collegeName=clg_name,subject1Marks=phy,subject2Marks=chem,subject3Marks=math,subject4Marks=eng,subject5Marks=mrt,totalMarks=total,persentage=per,grade=grade)
    obj.save
    msg="Data is Saved Successfully"
    return render(request,'result.html',sheet,{'msg':msg})
def employeePage(request):
    return render(request,'employee.html')

def employeeDataSave(request):
    eName=request.POST['emp_Name']
    sal=int(request.POST['sal'])
    design=request.POST['designation']

    obj= employees(empName=eName,salary=sal,designation=design)
    obj.save()
    msg="Data is Saved Successfully"
    return render(request,'employee.html',{'msg':msg})


    